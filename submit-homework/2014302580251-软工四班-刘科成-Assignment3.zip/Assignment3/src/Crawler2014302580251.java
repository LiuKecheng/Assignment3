import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class Crawler2014302580251 {
	public void Crawler() throws IOException{
		
		for(int i=0;i<=10;i++){
			
		String str=String.valueOf(1600+i);
		Document doc=Jsoup.connect("http://cs.whu.edu.cn/plus/view.php?aid="+str).get();
		Elements elements=doc.getElementsByClass("article");
		String text=elements.text();
		
		String name=crawlName(doc);
		String e=crawlEmail(text);
		String n=crawlNumber(text);
		
		Teacher2014302580251 teacher=new Teacher2014302580251(name,e,n,"");
		String all=teacher.getName()+teacher.getEmail()+" "+teacher.getTelephoneNumber();
		System.out.println(teacher.getName()+teacher.getEmail()+" "+teacher.getTelephoneNumber());
		DbHelper2014302580251 db=new DbHelper2014302580251();
		db.insertDB(all);
		}
	}
	
	
	public static String crawlName(Document d){
		Elements e=d.getElementsByTag("title");
		return e.text();
	}
	
	public static String crawlEmail(String str){
		Pattern p=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
		Matcher m=p.matcher(str);
		while(m.find()){
		return m.group();
		}
		return "";
	}
	
	public static String crawlNumber(String str){
		Pattern p=Pattern.compile("(1[0-9]{10})|(027-[0-9]{8})");
		Matcher m=p.matcher(str);
		while(m.find()){
		return m.group();
		}
		return "";
	}
 
}
