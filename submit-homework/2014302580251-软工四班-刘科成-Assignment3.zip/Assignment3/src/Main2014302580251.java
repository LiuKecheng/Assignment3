import java.io.IOException;

public class Main2014302580251 {
	public static void main(String[] args) throws IOException{
		Crawler2014302580251 crawler=new Crawler2014302580251();
		crawler.Crawler();
	}

}
