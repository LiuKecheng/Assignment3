import java.sql.DriverManager;
import java.sql.ResultSet;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class DbHelper2014302580251 {
	private static final String url = "jdbc:mysql://localhost:3306/abc";
	private static final String driver = "com.mysql.jdbc.Driver";
	public static Connection getCon() {
		Connection con=null;
		try {
			Class.forName(driver).newInstance();
			con = (Connection) DriverManager.getConnection(url,"root","123456");
			if (con != null) {
			System.out.println("�������ӵ����ݿ⣺" + con.getCatalog());
			}
			} 
		catch (Exception e) {
			System.out.println("�������ݿ�ʧ�ܣ�");
			e.printStackTrace();
			}
			return con;
	}
	
	public boolean insertDB(String FltNum) {
		Connection con = null;
		Statement stm = null;
		boolean flag = false;
		String sql = "insert into only values('" + FltNum + "')";
		try {
			con = getCon();
			stm = (Statement) con.createStatement();
			int i = stm.executeUpdate(sql);
			if (i > 0) {
				flag = true;
				System.out.println(flag + "�������ݳɹ���");
			}
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
		} finally {
			close(null, stm, con);
		}
		return flag;
	}
//�ر��������
	public void close(ResultSet rs, Statement stm, Connection con) {
		if (rs != null)
			try {
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		if (stm != null)
			try {
				stm.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		if (con != null)
			try {
				con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
}
