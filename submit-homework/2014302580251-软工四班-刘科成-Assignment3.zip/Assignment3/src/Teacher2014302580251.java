
public class Teacher2014302580251 {
	private String name;
	private String email;
	private String telephoneNumber;
	private String introduction;
	
	public Teacher2014302580251(String name,String email,String telephoneNumber,String introduction){
		this.name=name;
		this.email=email;
		this.telephoneNumber=telephoneNumber;
		this.introduction=introduction;
	}
	
	

	public String getName(){
		return name;
	}
	public void setName(String name){
		this.name=name;
	}
	
	public String getEmail(){
		return email;
	}
	public void setEmail(String email){
		this.email=email;
	}
	
	public String getTelephoneNumber(){
		return telephoneNumber;
	}
	public void setTelephoneNumber(String telephoneNumber){
		this.telephoneNumber=telephoneNumber;
	}
	
	public String getIntroduction(){
		return introduction;
	}
	public void setIntroduction(String introduction){
		this.introduction=introduction;
	}

}
